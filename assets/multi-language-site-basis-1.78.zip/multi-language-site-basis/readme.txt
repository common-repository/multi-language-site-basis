=== MultiLanguage Site===
Contributors: tazotodua
Tags: wordpress,multi,language,multilanguage,site,plugin,website,
Requires at least: 3.7
Tested up to: 4.2.1
Stable tag: 1.78
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 PLUGIN IS STOPPED TEMPORARILY. ADVICE: USE Wordpress MULTI-SITE FEATURE, INSTEAD OF multi-language plugins! 

== Description ==

**For building a Multi-Language Site!** 
 PLUGIN IS STOPPED TEMPORARILY. ADVICE: USE Wordpress MULTI-SITE FEATURE, INSTEAD OF multi-language plugins! 

>  (P.S. Note! This is a NON-SLOWING Plugin.  See other <a href="http://bitly.com/MWPLUGINS" target="_blank" alt="http://codesphpjs.blogspot.com/2014/10/nsp-non-slowing-plugins-for-wordpress.html">MUST-HAVE PLUGINS</a> for everyone. )


NOTE!!!!!!!  Plugin is maintained by ONLY ME, so , I dont know how many years I can keep this plugin maintained.. So, if someone interested, assist me to maintain this plugin (<a href="http://j.mp/contactmewordpresspluginstt" target="_blank">Contact Details</a>)

== Installation ==

1. Upload the entire folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently Asked Questions ==



== Screenshots ==

1. sample dropdown

== Changelog ==

= 1.67 =
* fixed pagination of category


= 1.62 =
* Added "Alternate Posts" possibility for language posts!!!
* Added ability to make such permalinks:  site.com/**`eng/category/subcategory/my-post-slug`**

= 1.60 =
* fixed some bugs

= 1.39 =
* fixed dozen of issues (Search+Category Queries)
* Added Some features.

= 1.38 =
* Plugin was completed..

= 1.1 =
* Initial release 